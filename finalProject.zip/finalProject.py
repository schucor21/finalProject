import os.path
import random

#initalized variables for each room
library = True
emptyRoom = True
workShop = True
cellar = True
wellRoom = True
LP = 7
gameStatus = 0
num_sides = 20
scroll = 0 
dagger = 0 
trap = ''
monster = ''
winValidation = tomorrow


#import statements
#variables - LP and game over 
#global functions 
    #dice rolling
    #reading text and files 
#rooms 1-5

#imports
#variables 
#function 1 
    #what the function does 
#While loop ______
    #if room: 1
    #what you can do in room 1
#End while loop 
#Game over 
#you can look for the scroll, don't look for it once you found it
#if search and havent found : (search and havent been found=true)
#else print already found
#save for the end

#set path to file
path = ''

#load the file, and print it, if it exists 

checkFile = os.path.isfile(path)

if checkFile == True:
    infile = open(path, 'r')
    outputFile = infile.read()
    print(outputFile)
else: 
    print('The file does not exist')


#Creating a loop that allows us to use the die more than once
while True:
    
    input('Press enter to roll a d20')
    
    #this is a random integer from 1 to 20 to our d20 variable
    d20 = random.randint(1,num_sides)
    print(d20)
    #interpret the outcomes of the d20 for 20 and 1
    if d20 == 1:
        print('CRITICAL FAIL')
    elif d20 == 20:
        print('CRITICAL HIT')
        
daggerAcquired = True
enemyHP = 6 
# Defining a function to control all dice rolls 
def roll_dice(num_sides):
    result = random.randint(1, num_sides)
    resultString = ''
    if result == 1:
        resultString = print('Critical Miss, you deal no damage to the enenmy')
    elif result == 20:
        resultString = print('Critical Hit')
    else:
        resultString = print('You rolled a', result, 'and the enemy lost', result, 'HP')
    return result, resultString

roll_dice(6)

#Attempt at enemy combat 
while enemyHP > 0:
    print('you were suprised by a monster in the room you just entered. It has', enemyHP, 'Health points left')
    if daggerAccquired == False:
        enemyHP = enemyHP - roll_dice(4)
    elif daggerAccquired == True:
        enemyHP = enemyHP - roll_dice(6)
    

# Display starting menu
def prompt():
        print('Welcome to The Gaurdian Lion Adventure')
            
        input('Press any key to continue')
        
    
# Tracks current room
current_room = 'Library'
nextRoom = int(input("Select the next room to travel to: \n 1: Library \n 2: well room \n",))
try:
    if nextRoom == 1:
        print('You are in the library')
    elif nextRoom == 2:
        print('You are bow in the well room')
except:
        print('Only enter number associated with the room')

# Result of last move
msg = ""

#Gameplay loop

while True:
    
    # Display info to player
    print(f'You are in the' [current_room])
    
    # Display msg
    print(msg)
    
    # Item indicator
    if "Item" in rooms[current_room].keys():
        
        nearby_item = rooms[current_room]['Item']
        
        if nearby_item not in inventory:
            
            else:
                print(f'You see a' [nearby_item])

        break

                
# Accept player's move as input
user_input = input('Enter your move:\n')

# Split move into words
next_move = user_input.split(' ')

#first word is action
action = next_move[0]

# moving between rooms
{
    if action = 'Go':
        
        try:
            current_room = room [current_room][direction]
            msg = f'You travel' [direction]
        except:
            msg = f'you can\'t go that way'
            
            
winvalidation = userInput.lower()



            
    
    
          
    
    
        
    